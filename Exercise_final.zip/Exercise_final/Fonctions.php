<?php

function vraiScrabble($mot)
    {
        //TRANSFORME LA CHAINE DE CARACTERE EN MINUSCULE
        $mot_minuscules = mb_strtolower($mot,'UTF-8');

        $pointage_mot=array("0","");
        $pointage_mot[1]="<table border=1><tr><th>Lettre</th><th>Points</th></tr>";
        //BOUCLE FOR QUI PASSE CHACUNE DES LETTRES DU MOT JUSQU'AU MAX (STRLEN) DU MOT
        for($i=0;$i<mb_strlen($mot_minuscules,'UTF-8');$i++)
        {
            switch ($mot_minuscules[$i])
        {
            case "d":
            case "g":
            case "m":
                $pointage_mot[1].="<tr><td>".$mot_minuscules[$i]."</td><td>"."2"."</td></tr>";
                $pointage_mot[0]+=2;
                break;
            case "b":
            case "c":
            case "p":
                $pointage_mot[1].="<tr><td>".$mot_minuscules[$i]."</td><td>"."3"."</td></tr>";
                $pointage_mot[0]+=3;
                break;
            case "f":
            case "h":
            case "v":
                $pointage_mot[1].="<tr><td>".$mot_minuscules[$i]."</td><td>"."4"."</td></tr>";
                $pointage_mot[0]+=4;
                break;
            case "j":
            case "q":
                $pointage_mot[1].="<tr><td>".$mot_minuscules[$i]."</td><td>"."8"."</td></tr>";
                $pointage_mot[0]+=8;
                break;
            case "k":
            case "w":
            case "x":
            case "y":
            case "z":
                $pointage_mot[1].="<tr><td>".$mot_minuscules[$i]."</td><td>"."10"."</td></tr>";
                $pointage_mot[0]+=10;
                break;
            default:
                $pointage_mot[1].="<tr><td>".$mot_minuscules[$i]."</td><td>"."1"."</td></tr>";
                $pointage_mot[0]+=1;
                break;
        }
        }
        $pointage_mot[1].="</table>";
        return $pointage_mot;
    }



/*  FONCTION HARVEY SCRABBLE
//  DESCRIPTION : PREND UN MOT EN PARAMÈTRE ET RETOURNE SON NOMBRE DE POINT SELON LES REGLES SUIVANTES : "1. Toutes les lettres dans un mot (ou une phrase) valent un point, sauf le H qui vaut 3 points, le Y qui vaut 10 points, le V qui vaut 5 points et le R qui vaut 2 points. 2. Si chacune des lettres H, V, Y et R sont présentes dans le mot, le mot vaut 20 points de plus. 3. Les points sont attribués que les lettres soient en minuscule ou en majuscule."
//
// PARAMÈTRES : $MOT (RECOIT UN MOT EN PARAMÈTRE (CHAINE DE CARACTERE).
//
// VALEUR DE RETOUR : RETOURNE UN NOMBRE DE POINT SELON LE MOT ET LES REGLES ETABLIES PAR LA LIGUE DE HARVEYSCRABBLE DU QUEBEC
//
//
*/
function HarveyScrabble($mot)
    {

        //TABLEAU ASSOCIATIF AVEC CHACUNE DES LETTRE ET SON POINTAGE INDIVIDUEL.
        $points = array("a"=>"1", "b"=>"1", "c"=>"1","d"=>"1", "e"=>"1", "f"=>"1","g"=>"1", "h"=>"3", "i"=>"1","j"=>"1", "k"=>"1", "l"=>"1","m"=>"1", "n"=>"1", "o"=>"1","p"=>"1", "q"=>"1", "r"=>"2","s"=>"1", "t"=>"1", "u"=>"1","v"=>"5", "w"=>"1", "x"=>"1", "y"=>"10", "z"=>"1");

        //TRANSFORME LA CHAINE DE CARACTERE EN MINUSCULE
        $mot_minuscules = mb_strtolower($mot,'UTF-8');

        $pointage_mot=0;

        //VARIABLES BOOLEENES POUR LE BONUS DE 20 POINTS QUI NE DOIT PAS ETRE ATTRIBUER PLUS QU'UNE FOIS
        $valeur_h=false;
        $valeur_v=false;
        $valeur_y=false;
        $valeur_r=false;
        $deja_eu_le_bonus=false;

        //BOUCLE FOR QUI PASSE CHACUNE DES LETTRES DU MOT JUSQU'AU MAX (STRLEN) DU MOT
        for($i=0;$i<mb_strlen($mot_minuscules,'UTF-8');$i++)
        {
            foreach($points as $lettre => $point_alloues)
            {
                if ($mot_minuscules[$i] == $lettre)
                {
                    $pointage_mot += $point_alloues;

                    //SWITCH CASE QUI PERMET DE TRAITER LES 4 LETTRES POUR LE BONUS
                    switch ($lettre)
                    {
                        case "h":$valeur_h=true;
                        break;
                        case "v":$valeur_v=true;
                        break;
                        case "y":$valeur_y=true;
                        break;
                        case "r":$valeur_r=true;
                        break;
                    }
                    //VALIDATION POUR LE BONUS
                    if ($valeur_h == true && $valeur_v == true && $valeur_y == true && $valeur_r == true && $deja_eu_le_bonus == false)
                    {
                        $deja_eu_le_bonus=true;
                        $pointage_mot +=20;
                    }
                }
            }
        }
        return $pointage_mot;
    }

    ?>