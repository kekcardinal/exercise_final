<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        require_once("Fonctions.php");
        
        $reg_exp = '/^[a-zA-Z]+$/i';
        $element_rechercher = "";
        
        if (isset($_GET["Afficher"]) && isset($_GET["element_rechercher"]) && isset($_GET["choix_scrabble"]))
        {
            $choix = $_GET["choix_scrabble"];
                    //VALIDATION AVEC PREG MATCH
                if(preg_match($reg_exp , $_GET["element_rechercher"]) === 0)
                {
                    echo "Veuillez entrer un mot avec seulement des lettres";
                }
                else
                {
                    $element_rechercher=$_GET["element_rechercher"];
                    if ($choix == "Vrai Scrabble")
                    {
                        echo vraiScrabble($element_rechercher)[0];
                        echo vraiScrabble($element_rechercher)[1];
                    }
                    else
                    {
                        echo HarveyScrabble($element_rechercher);
                    }
                }
        }
    ?>

<form method="GET">
        <select name="choix_scrabble">
                <option >Harvey Scrabble</option>
                <option >Vrai Scrabble</option>
            </select>
        Recherche: <input type="text" name="element_rechercher" value="<?php echo $element_rechercher; ?>">
        <input type="submit" name="Afficher" value="Calculer">
        
</form>

</body>
</html>